# BookMyConsultation

## Overview
This is a RESTful Backend System for a consultation booking platform.

## Setup
1. Clone the repository.
2. Install dependencies: `npm install`.
3. Set environment variables in `.env`.
4. Start the server: `npm run dev`.

